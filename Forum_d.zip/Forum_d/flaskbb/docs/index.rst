:orphan:

Welcome to FlaskBB
==================

FlaskBB is a classic forum software in a modern and fresh look.
It is written in Python using the web framework Flask.
FlaskBB is being distributed under the BSD 3-Clause License.


Links
-----

`website <https://flaskbb.org>`_ |
`documentation <https://flaskbb.readthedocs.org/en/latest/index.html/>`_ |
`source code <https://github.com/sh4nks/flaskbb>`_


.. include:: contents.rst.inc
