.. _tokens:

Tokens
======

.. module:: flaskbb.core.tokens

.. autoclass:: TokenActions
    :members:

.. autoclass:: Token

.. autoclass:: TokenSerializer
    :members:

.. autoclass:: TokenVerifier
    :members:

.. autoexception:: TokenError
    :members:
