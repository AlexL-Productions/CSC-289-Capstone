.. _hooks_form:

.. currentmodule:: flaskbb.plugins.spec

FlaskBB Form Hooks
==================

.. autofunction:: flaskbb_form_new_post_save
.. autofunction:: flaskbb_form_new_post
.. autofunction:: flaskbb_form_new_topic
.. autofunction:: flaskbb_form_new_topic_save
.. autofunction:: flaskbb_form_registration

