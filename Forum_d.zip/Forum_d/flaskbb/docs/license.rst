License
=======

.. include:: ../LICENSE
