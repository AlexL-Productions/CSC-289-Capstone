import logging

from pluggy import HookimplMarker

impl = HookimplMarker('flaskbb')

logger = logging.getLogger(__name__)
